# rickall
Total Rickall

To run the game:
- php -S localhost:8000
- Go to http://localhost:8000

OR: https://jacklehamster.github.io/rickall/

